// script.js
let tiktokClicked = false;
let youtubeClicked = false;

function selectButton(button) {
    if (button === 'tiktok') {
        tiktokClicked = true;
    }
    if (button === 'youtube') {
        youtubeClicked = true;
    }
}

document.getElementById('submit').addEventListener('click', function () {
    const input1 = document.getElementById('input1').value.trim();
    const input2 = document.getElementById('input2').value.trim();

    if (!input1 || !input2) {
        alert('Lütfen tüm alanları doldurun!');
        return;
    }

    if (!tiktokClicked || !youtubeClicked) {
        alert('Görev tamamlanamadı! TikTok ve YouTube butonlarına tıklayın.');
    } else {
        alert('Onaylandı!');
    }
});
